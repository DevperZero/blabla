#!/usr/bin/perl -w

my $folder = "C:\\Users\\TuoiHoang\\Desktop\\TestPerl";

my @files = glob "$folder/*.txt";
for (0..$#files){
    print "$files[$_]\n";
  $files[$_] =~ s/\.txt$//;
  
}
print "@files\n";
